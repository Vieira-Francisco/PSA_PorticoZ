﻿Imports MySql.Data.MySqlClient
Public Class Form1
    Inherits System.Windows.Forms.Form
    Dim cn As New MySqlConnection
    Dim cmd As New MySqlCommand
    Dim data_reader As MySqlDataReader


    Dim Mx As New ACTMULTILib.ActEasyIF
    Dim Controlo_Manual, Girar_Horario, Girar_AntiHorario, Modo_Referencia, Horario, AntiHorario, Zero_Z, Zerar, Ref_Aux, Zero_encontrado, botao_manual, velocidade_lenta, velocidade_media, velocidade_alta, HR, MR, LR As String

    Private Sub Buttonposicao_Click(sender As Object, e As EventArgs) Handles Buttonposicao.Click
        dados_posicao = CInt(TextBoxenviarposicao.Text)
        Mx.WriteDeviceRandom("D11", 1, dados_posicao - 65535)
        Mx.WriteDeviceRandom("M21", 1, "1")
    End Sub

    Dim dados_posicao As Integer

    Dim Botao_ciclo, Controlo_Aut As String
    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Buttonciclo.Click
        Mx.WriteDeviceRandom("X8", 1, "1")
        Mx.ReadDeviceRandom("X8", 1, Botao_ciclo)
        Mx.WriteDeviceRandom("X4", 1, "0")
        Mx.ReadDeviceRandom("X4", 1, Zerar)
        Mx.WriteDeviceRandom("X5", 1, "0")
        Mx.ReadDeviceRandom("X5", 1, botao_manual)
        Mx.WriteDeviceRandom("X6", 1, "0")
        Mx.ReadDeviceRandom("X6", 1, Controlo_Aut)
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Buttonautomatico.Click
        Mx.WriteDeviceRandom("X6", 1, "1")
        Mx.ReadDeviceRandom("X6", 1, Controlo_Aut)
        Mx.WriteDeviceRandom("X8", 1, "0")
        Mx.ReadDeviceRandom("X8", 1, Botao_ciclo)
        Mx.WriteDeviceRandom("X4", 1, "0")
        Mx.ReadDeviceRandom("X4", 1, Zerar)
        Mx.WriteDeviceRandom("X5", 1, "0")
        Mx.ReadDeviceRandom("X5", 1, botao_manual)
    End Sub

    Private Sub velocidaderapida_Click(sender As Object, e As EventArgs) Handles velocidaderapida.Click
        Mx.WriteDeviceRandom("M11", 1, "1")
        Mx.ReadDeviceRandom("M11", 1, velocidade_alta)
        Mx.WriteDeviceRandom("M12", 1, "0")
        Mx.ReadDeviceRandom("M12", 1, velocidade_media)
        Mx.WriteDeviceRandom("M13", 1, "0")
        Mx.ReadDeviceRandom("M13", 1, velocidade_lenta)
    End Sub

    Private Sub velocidademedia_Click(sender As Object, e As EventArgs) Handles velocidademedia.Click
        Mx.WriteDeviceRandom("M12", 1, "1")
        Mx.ReadDeviceRandom("M12", 1, velocidade_media)
        Mx.WriteDeviceRandom("M11", 1, "0")
        Mx.ReadDeviceRandom("M11", 1, velocidade_alta)
        Mx.WriteDeviceRandom("M13", 1, "0")
        Mx.ReadDeviceRandom("M13", 1, velocidade_lenta)
    End Sub

    Private Sub velocidadelenta_Click(sender As Object, e As EventArgs) Handles velocidadelenta.Click

        Mx.WriteDeviceRandom("M13", 1, "1")
        Mx.ReadDeviceRandom("M13", 1, velocidade_lenta)
        Mx.WriteDeviceRandom("M12", 1, "0")
        Mx.ReadDeviceRandom("M12", 1, velocidade_media)
        Mx.WriteDeviceRandom("M11", 1, "0")
        Mx.ReadDeviceRandom("M11", 1, velocidade_alta)

    End Sub




    Private Sub ButtonREF_Click(sender As Object, e As EventArgs) Handles ButtonREF.Click
        Mx.WriteDeviceRandom("X4", 1, "1")
        Mx.ReadDeviceRandom("X4", 1, Zerar)
        Mx.WriteDeviceRandom("X5", 1, "0")
        Mx.ReadDeviceRandom("X5", 1, botao_manual)
        Mx.WriteDeviceRandom("X8", 1, "0")
        Mx.ReadDeviceRandom("X8", 1, Botao_ciclo)
        Mx.WriteDeviceRandom("X6", 1, "0")
        Mx.ReadDeviceRandom("X6", 1, Controlo_Aut)


        Mx.ReadDeviceRandom("X7", 1, Zero_Z)
        If Zero_Z = "0" Then
            Mx.WriteDeviceRandom("M8", 1, "0")
            Mx.ReadDeviceRandom("M8", 1, Zero_encontrado)
            TextBox1.Text = "A encontrar o Zero..."
        Else
            TextBox1.Text = "Zero Encontrado!"
            Mx.WriteDeviceRandom("M8", 1, "1")
            Mx.ReadDeviceRandom("M8", 1, Zero_encontrado)
        End If

    End Sub


    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Mx.ActLogicalStationNumber = 1
        Mx.Open()
        Me.Text = "Controlador"
        Btn_AH.Enabled = False
        Btn_H.Enabled = False
        Btn_parar.Enabled = False
       
        btModo.Text = "Manual"



        cn.ConnectionString = "Server = localhost; User Id = root; Database= portico"
        Try
            If cn.State = ConnectionState.Closed Then
                cn.Open()
                MsgBox("Ligacao correta a base de dados")
            End If
        Catch ex As Exception
            cn.Close()
            MsgBox("Ligacao incorreta a base de dados")
        End Try
        cmd.Connection = cn
    End Sub

    Private Sub btModo_Click(sender As Object, e As EventArgs) Handles btModo.Click
        If btModo.Text = "Manual" Then

            Mx.WriteDeviceRandom("X5", 1, "1")
            Mx.ReadDeviceRandom("X5", 1, botao_manual)
            Mx.WriteDeviceRandom("X4", 1, "0")
            Mx.ReadDeviceRandom("X4", 1, Zerar)
            Mx.ReadDeviceRandom("M3", 1, Controlo_Manual)
            Mx.WriteDeviceRandom("X6", 1, "0")
            Mx.ReadDeviceRandom("X6", 1, Controlo_Aut)

            If Controlo_Manual = "1" Then
                ToolStripStatusLabelModo.Text = "Modo: Manual"
                Btn_AH.Enabled = True
                Btn_H.Enabled = True
                Btn_parar.Enabled = True

            Else
                ToolStripStatusLabelModo.Text = "Erro Modo Manual"

                Btn_AH.Enabled = False
                Btn_H.Enabled = False
                Btn_parar.Enabled = False

            End If
        End If
    End Sub

    Private Sub btSair_Click(sender As Object, e As EventArgs) Handles btSair.Click
        Mx.WriteDeviceRandom("X2", 1, "0")
        Mx.WriteDeviceRandom("X3", 1, "0")
        Mx.WriteDeviceRandom("X5", 1, "0")
        Mx.WriteDeviceRandom("X7", 1, "0")
        Mx.WriteDeviceRandom("M3", 1, "0")
        Mx.WriteDeviceRandom("M4", 1, "0")
        Mx.WriteDeviceRandom("M8", 1, "0")
        End
    End Sub

    Private Sub Btn_parar_Click(sender As Object, e As EventArgs) Handles Btn_parar.Click
        Mx.WriteDeviceRandom("X3", 1, "0")
        Mx.ReadDeviceRandom("X3", 1, Girar_Horario)
        Mx.WriteDeviceRandom("X2", 1, "0")
        Mx.ReadDeviceRandom("X2", 1, Girar_AntiHorario)

        If Girar_Horario = "0" & Girar_AntiHorario = "0" Then
            ToolStripStatusLabelSentido.Text = "Parado!"
        End If

    End Sub

    Private Sub Btn_H_Click(sender As Object, e As EventArgs) Handles Btn_H.Click
        CheckBox1.Checked = False
        CheckBox2.Checked = True

        Mx.WriteDeviceRandom("X2", 1, "0")
        Mx.ReadDeviceRandom("X2", 1, Girar_Horario)
            Mx.WriteDeviceRandom("X3", 1, "1")
            Mx.ReadDeviceRandom("X3", 1, Girar_AntiHorario)



            Mx.ReadDeviceRandom("M4", 1, Modo_Referencia)

        If Girar_Horario = "1" & Girar_AntiHorario = "0" Then
            ToolStripStatusLabelSentido.Text = "Sentido Horário!"

        Else
            Mx.WriteDeviceRandom("X2", 1, "0")

            ToolStripStatusLabelSentido.Text = "Parado!"

        End If

    End Sub

    Private Sub Btn_AH_Click_1(sender As Object, e As EventArgs) Handles Btn_AH.Click
        CheckBox1.Checked = True
        CheckBox2.Checked = False

        Mx.WriteDeviceRandom("X2", 1, "1")
        Mx.ReadDeviceRandom("X2", 1, Girar_Horario)
        Mx.WriteDeviceRandom("X3", 1, "0")
        Mx.ReadDeviceRandom("X3", 1, Girar_AntiHorario)



        Mx.ReadDeviceRandom("M4", 1, Modo_Referencia)

        If Girar_Horario = "0" & Girar_AntiHorario = "1" Then
            ToolStripStatusLabelSentido.Text = "Sentido Horário!"

        Else
            Mx.WriteDeviceRandom("X3", 1, "0")

            ToolStripStatusLabelSentido.Text = "Parado!"

        End If

    End Sub
End Class
