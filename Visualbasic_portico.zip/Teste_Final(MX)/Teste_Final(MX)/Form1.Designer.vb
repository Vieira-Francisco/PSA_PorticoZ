﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Descartar substituições de formulário para limpar a lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Exigido pelo Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'OBSERVAÇÃO: o procedimento a seguir é exigido pelo Windows Form Designer
    'Pode ser modificado usando o Windows Form Designer.  
    'Não o modifique usando o editor de códigos.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.btSair = New System.Windows.Forms.Button()
        Me.Btn_H = New System.Windows.Forms.Button()
        Me.Btn_parar = New System.Windows.Forms.Button()
        Me.btModo = New System.Windows.Forms.Button()
        Me.StatusStrip1 = New System.Windows.Forms.StatusStrip()
        Me.ToolStripStatusLabelModo = New System.Windows.Forms.ToolStripStatusLabel()
        Me.ToolStripStatusLabelSentido = New System.Windows.Forms.ToolStripStatusLabel()
        Me.Btn_AH = New System.Windows.Forms.Button()
        Me.ButtonREF = New System.Windows.Forms.Button()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.BackgroundWorker1 = New System.ComponentModel.BackgroundWorker()
        Me.CheckBox1 = New System.Windows.Forms.CheckBox()
        Me.CheckBox2 = New System.Windows.Forms.CheckBox()
        Me.TextBoxenviarposicao = New System.Windows.Forms.TextBox()
        Me.Splitter1 = New System.Windows.Forms.Splitter()
        Me.velocidadelenta = New System.Windows.Forms.Button()
        Me.velocidademedia = New System.Windows.Forms.Button()
        Me.velocidaderapida = New System.Windows.Forms.Button()
        Me.Buttonautomatico = New System.Windows.Forms.Button()
        Me.Buttonciclo = New System.Windows.Forms.Button()
        Me.Buttonposicao = New System.Windows.Forms.Button()
        Me.StatusStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'btSair
        '
        Me.btSair.BackColor = System.Drawing.SystemColors.ControlDarkDark
        Me.btSair.Location = New System.Drawing.Point(1053, 328)
        Me.btSair.Name = "btSair"
        Me.btSair.Size = New System.Drawing.Size(98, 38)
        Me.btSair.TabIndex = 0
        Me.btSair.Text = "Sair"
        Me.btSair.UseVisualStyleBackColor = False
        '
        'Btn_H
        '
        Me.Btn_H.Font = New System.Drawing.Font("Microsoft YaHei", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_H.Location = New System.Drawing.Point(752, 316)
        Me.Btn_H.Name = "Btn_H"
        Me.Btn_H.Size = New System.Drawing.Size(128, 50)
        Me.Btn_H.TabIndex = 2
        Me.Btn_H.Text = "Sentido Horário"
        Me.Btn_H.UseVisualStyleBackColor = True
        '
        'Btn_parar
        '
        Me.Btn_parar.BackColor = System.Drawing.Color.Red
        Me.Btn_parar.Font = New System.Drawing.Font("Microsoft YaHei", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_parar.Location = New System.Drawing.Point(616, 321)
        Me.Btn_parar.Name = "Btn_parar"
        Me.Btn_parar.Size = New System.Drawing.Size(81, 41)
        Me.Btn_parar.TabIndex = 7
        Me.Btn_parar.Text = "Parar"
        Me.Btn_parar.UseVisualStyleBackColor = False
        '
        'btModo
        '
        Me.btModo.BackColor = System.Drawing.SystemColors.ActiveBorder
        Me.btModo.Font = New System.Drawing.Font("Microsoft YaHei", 12.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btModo.Location = New System.Drawing.Point(35, 48)
        Me.btModo.Name = "btModo"
        Me.btModo.Size = New System.Drawing.Size(183, 47)
        Me.btModo.TabIndex = 9
        Me.btModo.Text = "Manual"
        Me.btModo.UseVisualStyleBackColor = False
        '
        'StatusStrip1
        '
        Me.StatusStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripStatusLabelModo, Me.ToolStripStatusLabelSentido})
        Me.StatusStrip1.Location = New System.Drawing.Point(0, 421)
        Me.StatusStrip1.Name = "StatusStrip1"
        Me.StatusStrip1.Size = New System.Drawing.Size(1169, 22)
        Me.StatusStrip1.TabIndex = 15
        Me.StatusStrip1.Text = "StatusStrip1"
        '
        'ToolStripStatusLabelModo
        '
        Me.ToolStripStatusLabelModo.Name = "ToolStripStatusLabelModo"
        Me.ToolStripStatusLabelModo.Size = New System.Drawing.Size(39, 17)
        Me.ToolStripStatusLabelModo.Text = "Modo"
        '
        'ToolStripStatusLabelSentido
        '
        Me.ToolStripStatusLabelSentido.Name = "ToolStripStatusLabelSentido"
        Me.ToolStripStatusLabelSentido.Size = New System.Drawing.Size(47, 17)
        Me.ToolStripStatusLabelSentido.Text = "Sentido"
        '
        'Btn_AH
        '
        Me.Btn_AH.Font = New System.Drawing.Font("Microsoft YaHei", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_AH.Location = New System.Drawing.Point(438, 314)
        Me.Btn_AH.Name = "Btn_AH"
        Me.Btn_AH.Size = New System.Drawing.Size(134, 52)
        Me.Btn_AH.TabIndex = 23
        Me.Btn_AH.Text = "Sentido Anti-Horário"
        Me.Btn_AH.UseVisualStyleBackColor = True
        '
        'ButtonREF
        '
        Me.ButtonREF.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.ButtonREF.Font = New System.Drawing.Font("Microsoft YaHei", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ButtonREF.Location = New System.Drawing.Point(35, 279)
        Me.ButtonREF.Name = "ButtonREF"
        Me.ButtonREF.Size = New System.Drawing.Size(183, 48)
        Me.ButtonREF.TabIndex = 24
        Me.ButtonREF.Text = "Zerar"
        Me.ButtonREF.UseVisualStyleBackColor = False
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(35, 323)
        Me.TextBox1.Multiline = True
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(183, 43)
        Me.TextBox1.TabIndex = 25
        '
        'CheckBox1
        '
        Me.CheckBox1.AutoSize = True
        Me.CheckBox1.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.CheckBox1.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.CheckBox1.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CheckBox1.Location = New System.Drawing.Point(407, 48)
        Me.CheckBox1.Name = "CheckBox1"
        Me.CheckBox1.Size = New System.Drawing.Size(13, 12)
        Me.CheckBox1.TabIndex = 26
        Me.CheckBox1.UseVisualStyleBackColor = False
        '
        'CheckBox2
        '
        Me.CheckBox2.AutoSize = True
        Me.CheckBox2.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.CheckBox2.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.CheckBox2.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Strikeout), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CheckBox2.Location = New System.Drawing.Point(926, 50)
        Me.CheckBox2.Name = "CheckBox2"
        Me.CheckBox2.Size = New System.Drawing.Size(13, 12)
        Me.CheckBox2.TabIndex = 27
        Me.CheckBox2.UseVisualStyleBackColor = False
        '
        'TextBoxenviarposicao
        '
        Me.TextBoxenviarposicao.Location = New System.Drawing.Point(986, 267)
        Me.TextBoxenviarposicao.Multiline = True
        Me.TextBoxenviarposicao.Name = "TextBoxenviarposicao"
        Me.TextBoxenviarposicao.Size = New System.Drawing.Size(165, 31)
        Me.TextBoxenviarposicao.TabIndex = 28
        '
        'Splitter1
        '
        Me.Splitter1.Location = New System.Drawing.Point(0, 0)
        Me.Splitter1.Name = "Splitter1"
        Me.Splitter1.Size = New System.Drawing.Size(3, 421)
        Me.Splitter1.TabIndex = 29
        Me.Splitter1.TabStop = False
        '
        'velocidadelenta
        '
        Me.velocidadelenta.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.velocidadelenta.Location = New System.Drawing.Point(986, 46)
        Me.velocidadelenta.Name = "velocidadelenta"
        Me.velocidadelenta.Size = New System.Drawing.Size(165, 23)
        Me.velocidadelenta.TabIndex = 30
        Me.velocidadelenta.Text = "Velocidade lenta"
        Me.velocidadelenta.UseVisualStyleBackColor = True
        '
        'velocidademedia
        '
        Me.velocidademedia.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.velocidademedia.Location = New System.Drawing.Point(986, 90)
        Me.velocidademedia.Name = "velocidademedia"
        Me.velocidademedia.Size = New System.Drawing.Size(165, 23)
        Me.velocidademedia.TabIndex = 31
        Me.velocidademedia.Text = "Velocidade media"
        Me.velocidademedia.UseVisualStyleBackColor = True
        '
        'velocidaderapida
        '
        Me.velocidaderapida.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.velocidaderapida.Location = New System.Drawing.Point(986, 133)
        Me.velocidaderapida.Name = "velocidaderapida"
        Me.velocidaderapida.Size = New System.Drawing.Size(165, 23)
        Me.velocidaderapida.TabIndex = 32
        Me.velocidaderapida.Text = "Velocidade alta"
        Me.velocidaderapida.UseVisualStyleBackColor = True
        '
        'Buttonautomatico
        '
        Me.Buttonautomatico.BackColor = System.Drawing.SystemColors.AppWorkspace
        Me.Buttonautomatico.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Buttonautomatico.Location = New System.Drawing.Point(35, 118)
        Me.Buttonautomatico.Name = "Buttonautomatico"
        Me.Buttonautomatico.Size = New System.Drawing.Size(203, 51)
        Me.Buttonautomatico.TabIndex = 33
        Me.Buttonautomatico.Text = "Posicionamento automatico"
        Me.Buttonautomatico.UseVisualStyleBackColor = False
        '
        'Buttonciclo
        '
        Me.Buttonciclo.BackColor = System.Drawing.SystemColors.ActiveBorder
        Me.Buttonciclo.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Buttonciclo.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Buttonciclo.Location = New System.Drawing.Point(35, 188)
        Me.Buttonciclo.Name = "Buttonciclo"
        Me.Buttonciclo.Size = New System.Drawing.Size(169, 44)
        Me.Buttonciclo.TabIndex = 34
        Me.Buttonciclo.Text = "Sequencia"
        Me.Buttonciclo.UseVisualStyleBackColor = False
        '
        'Buttonposicao
        '
        Me.Buttonposicao.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Buttonposicao.Location = New System.Drawing.Point(1060, 238)
        Me.Buttonposicao.Name = "Buttonposicao"
        Me.Buttonposicao.Size = New System.Drawing.Size(91, 23)
        Me.Buttonposicao.TabIndex = 35
        Me.Buttonposicao.Text = "Posicionar"
        Me.Buttonposicao.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = Global.Teste_Final_MX_.My.Resources.Resources.render_portico_2
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(1169, 443)
        Me.Controls.Add(Me.Buttonposicao)
        Me.Controls.Add(Me.Buttonciclo)
        Me.Controls.Add(Me.Buttonautomatico)
        Me.Controls.Add(Me.velocidaderapida)
        Me.Controls.Add(Me.velocidademedia)
        Me.Controls.Add(Me.velocidadelenta)
        Me.Controls.Add(Me.Splitter1)
        Me.Controls.Add(Me.TextBoxenviarposicao)
        Me.Controls.Add(Me.CheckBox2)
        Me.Controls.Add(Me.CheckBox1)
        Me.Controls.Add(Me.TextBox1)
        Me.Controls.Add(Me.ButtonREF)
        Me.Controls.Add(Me.Btn_AH)
        Me.Controls.Add(Me.StatusStrip1)
        Me.Controls.Add(Me.btModo)
        Me.Controls.Add(Me.Btn_parar)
        Me.Controls.Add(Me.Btn_H)
        Me.Controls.Add(Me.btSair)
        Me.Name = "Form1"
        Me.Text = "Controlador"
        Me.StatusStrip1.ResumeLayout(False)
        Me.StatusStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btSair As Button
    Friend WithEvents Btn_H As Button
    Friend WithEvents Btn_parar As Button
    Friend WithEvents btModo As Button
    Friend WithEvents StatusStrip1 As StatusStrip
    Friend WithEvents ToolStripStatusLabelModo As ToolStripStatusLabel
    Friend WithEvents ToolStripStatusLabelSentido As ToolStripStatusLabel
    Friend WithEvents Btn_AH As Button
    Friend WithEvents ButtonREF As Button
    Friend WithEvents TextBox1 As TextBox
    Friend WithEvents BackgroundWorker1 As System.ComponentModel.BackgroundWorker
    Friend WithEvents CheckBox1 As CheckBox
    Friend WithEvents CheckBox2 As CheckBox
    Friend WithEvents TextBoxenviarposicao As TextBox
    Friend WithEvents Splitter1 As Splitter
    Friend WithEvents velocidadelenta As Button
    Friend WithEvents velocidademedia As Button
    Friend WithEvents velocidaderapida As Button
    Friend WithEvents Buttonautomatico As Button
    Friend WithEvents Buttonciclo As Button
    Friend WithEvents Buttonposicao As Button
End Class
