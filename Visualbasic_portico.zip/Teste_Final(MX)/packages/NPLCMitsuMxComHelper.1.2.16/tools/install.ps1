param($installPath, $toolsPath, $package, $project)

$project.Object.References | Where-Object { $_.Name -eq "Interop.ActProgTypeLib" } |  ForEach-Object { $_.EmbedInteropTypes = $false }
$project.Object.References | Where-Object { $_.Name -eq "Interop.ActUtlTypeLib" } |  ForEach-Object { $_.EmbedInteropTypes = $false }